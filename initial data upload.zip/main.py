import itertools

import numpy as np
import openpyxl
import pandas as pd
import random

from matplotlib import pyplot as plt
from scipy.optimize import minimize
from sklearn.linear_model import Lasso
import networkx as nx
import tqdm
import math
from sklearn.metrics import mean_squared_error
import json
import builtins

def run_code(number):
    #直觉模糊数求和计算
    def sum_mu(a1,a2):
        a=0
        a=a1+a2-a1*a2 
        return a
    def sum_nu(b1,b2):
        b=0
        b=b1*b2
        return b
    #直觉模糊数乘整数计算
    def times_mu(a1,a2): #a1是整数
        a=0
        a=1-pow((1-a2),a1)
        return a
    def times_nu(b1,b2): #b1是整数
        b=0
        b=pow(b2,b1)
        return b

    # 计算hesitation
    def fz(vector,num_alternative,num_attribute):
        matrix=np.zeros((num_alternative,num_attribute))
        for i in range(num_alternative):
            for j in range (num_attribute):
                matrix[i][j]=1-vector[i*num_attribute*2+j*2]-vector[i*num_attribute*2+j*2+1]
        return matrix

    def normalized(C1):
        for i in range(len(C1)):
            C1[i]=(C1[i]-min(C1))/(max(C1)-min(C1))
        return C1

    def Ccollec(data):
        C = []
        w_group = []
        for s0 in s:
            C1 = [0] * line
            w1 = 0
            for i in s0:
                w1 = w1 + w[i-1]
            w_group.append(w1)
            for i in s0:
                for j in range(line): #for j in range(0,line,2)
                    C1[j] = C1[j] + w[i-1] * data[i-1][j] / w1
            C.append(C1)

        collective = [0] * line
        for i in range(line):
            for j in range(len(C)):
                collective[i] = collective[i] + w_group[j] * C[j][i]
        return C,collective #C是子组的观点矩阵，collective是整体的观点矩阵

    def dis(C1,C2):
        d=0
        for i in range(len(C1)):
            d+=(C1[i]-C2[i])*(C1[i]-C2[i])
        d=math.sqrt(d/len(C1))
        return d

    def GCL_calcu(C,collective):
        d=[]
        for i in C:
            d.append(dis(i,collective))
        GCL=builtins.round(1-sum(d)/len(C),3)
        return GCL

    def keyleader(key,CL,index_of_key,data,u):
        for i in range(len(data[key-1])):
            key_opinion_result=CL[key-1]*data[key-1]+np.dot(u,data[index_of_key])*(1-CL[key-1])/sum(u)
        return key_opinion_result

    def communicator(c1,CL,index_of_com,data,u):
        com_opinion_result=CL[c1-1]*data[c1-1]+np.dot(u,data[index_of_com])*(1-CL[c1-1])/sum(u)
        return com_opinion_result

    def commonleader(l,c,CL,data):
        comleader_opinion_result=CL[l-1]*data[l-1]+(1-CL[l-1])*data[c-1]
        return comleader_opinion_result

    def ordinary(o,l,c,data):
        beta1=CD_matrix[o-1][l-1]/CD[f'CD_{o}']
        beta2=CD_matrix[o-1][c-1]/CD[f'CD_{o}']
        ord_opinion_result=[0]*len(data[l-1])
        for i in range(len(data[l-1])):
            ord_opinion_result[i] = (1-beta1-beta2) * data[o-1][i] + beta1 * data[l-1][i]+beta2 * data[c-1][i]
        return ord_opinion_result

    num_alternative=4
    num_attribute=3
    bn=num_alternative * num_attribute #矩阵的总列数除2
    eat=np.full((1, num_alternative), 1/num_alternative)
    #属性权重
    attri1=[1/3,1/3,1/3]
    #参数
    sigma1=0.5
    sigma2=1/3
    sigma3=1/3
    sigma4=1/3
    GCL_threshold=0.9
    theta=0.3
    max_communicate=10 #最多沟通人数
    GCL_values=[]
    GCL0_values=np.empty((0,2))
    

    # 导入稀疏系数.py文件中生成的初始观点
    data=pd.read_excel(f"E:/科研/10.PE-DF/0.实验/代码/basic_data_u1_maxcom10/200DM_4alternative_3attribute_{number}.xlsx",sheet_name='initial_opinion',header=None)
    data=data.values
    num_people,dim=data.shape
    print(num_people)
    print(dim)

    #导入稀疏系数矩阵
    workbook=openpyxl.load_workbook(f'E:/科研/10.PE-DF/0.实验/代码/basic_data_u1_maxcom10/200DM_4alternative_3attribute_{number}.xlsx')
    sheet=workbook['SR']
    data0=[]
    for row in sheet.iter_rows(min_row=1,min_col=1): #空值赋0，非空值保留，其实没啥必要
        row_data=[]
        for cell in row:
            if cell.value is None:
                row_data.append(0)
            else:
                row_data.append(cell.value)
        data0.append(row_data)

    #读取聚类结果
    with open(f'E:/科研/10.PE-DF/0.实验/代码/basic_data_u1_maxcom10/cluster_result_{number}.json', 'r') as json_file:
        s = json.load(json_file)
    #print("s=",s)

    line=dim
    print("line:",line)
    r=np.zeros((len(data0),len(data0[1])))
    for i in range(num_people): #data0矩阵中大于0.3的保留，小于0.3的赋0
        for j in range(num_people):
            if data0[i][j]>theta:
                r[i][j]=data0[i][j]

    # 创建一个有向图
    G = nx.DiGraph()
    for i in range(num_people):
        G.add_node(i+1, label=str(i + 1))

    for i in range(num_people):
        for j in range(num_people):
            if r[i][j]>0:
                G.add_edge(i+1,j+1,weight=r[i][j])

    #计算每个节点的总度，以及所有节点的总度之和
    IRD=G.degree() 
    print(IRD)

    IRDsum=0
    hh=[] #记录每个节点的总度
    for i in range(num_people):
        IRDsum=IRDsum+IRD[i+1]
        hh.append(IRD[i+1])
    print("IRD:",IRDsum)
    print("hh=",hh)

    #计算权重
    # random.seed(120)
    #导入决策者知识水平
    b=pd.read_excel(f"E:/科研/10.PE-DF/0.实验/代码/basic_data_u1_maxcom10/200DM_4alternative_3attribute_{number}.xlsx",sheet_name='knowledge level',header=None)
    b=b.values.flatten()
    #b=np.round(np.random.rand(num_people), 1)
    print(b)

    w=[]
    for i in range(num_people):
        w_i=(sigma1*b[i]+(1-sigma1)*IRD[i+1]/IRDsum)/(sigma1*sum(b)+(1-sigma1))
        w.append(w_i)
    #print(w)

    #计算GCL
    C,collective=Ccollec(data)
    #print("subgroup matrix:",C)
    #print("collective matrix:",collective)

    GCL=GCL_calcu(C,collective)
    GCL_values.append(GCL)
    print("初始共识GCL:",GCL)

    #计算confidence level
    o=[]
    for i in range(num_people):
        t1=np.dot(fz(data[i], num_alternative, num_attribute),np.transpose(attri1))
        o.append(1-np.dot(eat,t1))
    CL=o.copy()
    print("confidence level:",CL)

    #计算意见相似度
    CD_matrix = np.zeros((num_people,num_people))
    for i in range(num_people):
        for j in range(num_people):
            CD_matrix[i][j]=1-dis(data[i],data[j])
    #print("opinion similarity:",CD_matrix)

    GCDm=0
    CD={}
    GCD=[]
    for m in s:
        for i in m:
            CD_i = 0
            for j in m:
                if i != j:
                    CD_i += 1 - dis(data[i-1], data[j-1])
            CD[f'CD_{i}'] = CD_i
            GCDm += CD_i
        GCD.append(GCDm)

    #选拔沟通者
    index=[]
    for t in range(len(s)):
        m=s[t]
        CM_1 = [0] * (num_people+1)
        for i in m:
            CM_1[i] = sigma2 * CL[i - 1] + sigma3 * CD[f'CD_{i}'] / GCD[t] + sigma4 * hh[i - 1] / max(hh)
        value1 = max(CM_1)
        index1 = CM_1.index(value1)
        index.append(index1)
    print("沟通者:",index)

    #确定领导者
    leader=[]
    for m in s:
        leader_m=[]
        for j in m:
            leader_m.append(hh[j-1])
        if leader_m.count(max(leader_m))>1:
            indices = [i for i, value in enumerate(leader_m) if value == max(leader_m)]
            mm = [m[i] for i in indices]
            dd=[]
            for tm in mm:
                dd.append(dis(data[tm-1],collective))
            leader.append(m[dd.index(min(dd))])
        else:
            leader.append(m[leader_m.index(max(leader_m))])
    print("leader:",leader)

    com= index.copy()
    print("com:",com)

    #确定关键领导者
    if hh.count(max(hh))>1:
        mmm=[i + 1 for i, value in enumerate(hh) if value == max(hh)]
        ddd=[]
        for tmm in mmm:
            ddd.append(dis(data[tmm-1],collective))
        key=mmm[ddd.index(min(ddd))]
    else:
        key=hh.index(max(hh))+1
    print("key:",key)

    #删除沟通者中的关键领导者，或者删除关键领导者所在子群的沟通者，关键领导者自动成为子群的沟通者
    if key in com:
        com.remove(key)
        com11 = com.copy()
        print("去除key leader后的沟通者:",com11)

    else: 
        if key in leader:
            com11 = com.copy()
            dai11=leader.index(key) #查找领导者中关键领导者所在的子群
            #print(dai11)
            dai=com11[dai11]
            com11.remove(dai) #移除关键领导者所在子群的沟通者
            #print(com11)
        else:
            com11=com.copy()
    com_copy=com11.copy()
    print("com_copy:",com_copy)

    #优化模型
    def objective(indices, data_copy):
        # 提取参数
        round.append(n+1)
        mmm=0
        data_dai=data_copy.copy()
        com_sequence=[]
        sequence=[]
        for i in com_copy:
            com_dai = com_copy.copy()
            com_dai.insert(0,key)
            com_index=[com_dai[ii]-1 for ii in indices[mmm]] #减1是为了到communicator函数中引用到正确位置的决策者观点
            com_sequence=[x+1 for x in com_index]
            sequence.append(com_sequence)
            data_dai[i-1] = communicator(i,CL,com_index,data_copy,u1)
            mmm += 1

        # 更新keyleader
        key_sequence=[]
        com_dai.remove(com_dai[0])
        key_index=[com_dai[iii]-1 for iii in indices[mmm]] #需要减1，理由同上
        key_sequence=[x+1 for x in key_index]
        sequence.append(key_sequence)
        data_dai[key-1] = keyleader(key,CL,key_index,data_dai,u1)
        C_dai, collective_dai = Ccollec(data_dai)
        # 重新计算GCL
        GCL0 = GCL_calcu(C_dai, collective_dai)  # 这里C和collective应当用data_copy的结果来重新计算
        # 计算GCL的变化，注意我们希望最大化GCL的增加，所以取负数
        
        return -(GCL0 - GCL),data_dai,sequence


    #确定首因效应的权重
    u1=[0]*max_communicate
    u2=[0]*max_communicate
    u3=[0]*max_communicate
    for g in range(max_communicate):
        u1[g]=(max_communicate-g)/10
        u2[g]=1/(g+2)
        u3[g]=math.log(max_communicate-g)
    print("u1=",u1)
    print("u2=",u2)
    print("u3=",u3)

    #开始迭代
    data_update=data
    n=0
    round=[]
    while GCL<GCL_threshold:
        n=n+1
        print("第" + str(n) + "次迭代：")

        best_score = float('inf') #将best_score初始化为正无穷大
        best_params = None

        verified_indices=[]
        ro=0
        while ro<300:
            data_copy = np.copy(data_update)
            indices=[]
            for i in range(len(com_copy)):
                random_numbers = [x+1 for x in random.sample([x for x in range(len(com_copy)) if x!=i], max_communicate-1)] #沟通者沟通次序：生成包含(最多沟通者人数-1)个随机数的向量，排除自己，同时生成的数+1，因为要在第一位插入0
                random_numbers.insert(0,0) #在开始的时候插入0，代表第一个和关键领导者沟通
                indices.append(random_numbers)
            random_numbers2 = random.sample(range(len(com_copy)), max_communicate) #关键领导者沟通次序：生成包含(最多沟通者)个随机数的向量
            indices.append(random_numbers2)
            if indices in verified_indices:
                continue
        
            verified_indices.append(indices)
            score,data_temporary,sequence_temporary = objective(indices,data_copy)
            if score < best_score:
                best_score = score
                best_params = sequence_temporary
                best_indices = indices
            ro=ro+1
    
        # 输出最佳解
        print('Best score:', best_score)
        print('Best parameters:', best_params)
        mx,data_update,best_params=objective(best_indices,data_copy)
        GCL0=GCL-mx
        print("GCL0:",GCL0)
        kkn=0
        GCL0_zhuijia=[kkn,GCL0]
        GCL0_values=np.vstack([GCL0_values,GCL0_zhuijia])
        while GCL0 <= GCL:
            print("本次交流没有提高共识")
            kkn+=1
            if kkn<=10:
                best_score = float('inf') #将best_score初始化为正无穷大
                # 遍历所有可能的索引组合
                ro=0
                while ro<300:
                    indices=[]
                    for i in range(len(com_copy)):
                        random_numbers = [x+1 for x in random.sample([x for x in range(len(com_copy)) if x!=i], max_communicate-1)]
                        random_numbers.insert(0,0)
                        indices.append(random_numbers)
                    random_numbers2 = random.sample(range(len(com_copy)), max_communicate)
                    indices.append(random_numbers2)
                    if indices in verified_indices:
                        continue
                
                    verified_indices.append(indices)
                    score,data_temporary,sequence_temporary = objective(indices, data_copy)
                    if score < best_score:
                        best_score = score
                        best_params = sequence_temporary
                        best_indices = indices
                    ro=ro+1
                
                # 输出最佳解
                print('Best score:', best_score)
                print('Best parameters:', best_params)
                mx,data_update,best_params = objective(best_indices, data_copy)
                GCL0 = GCL - mx
                print("核心圈进行第"+str(kkn+1)+"次交流后,GCL0:", GCL0)
                GCL0_zhuijia=[kkn,GCL0]
                GCL0_values=np.vstack([GCL0_values,GCL0_zhuijia])
            else:
                break
        ordinarypeople=[]
        yuer=0
        for m in s:
            ordinarypeople1 = m.copy()
            ordinarypeople1.remove(index[yuer]) #删除子组中的沟通者
            if leader[yuer] in ordinarypeople1:
                ordinarypeople1.remove(leader[yuer]) #删除子组中的领导者
            yuer+=1
            ordinarypeople.append(ordinarypeople1)
        comleader = leader.copy()
    
        data_update_copy=np.copy(data_update)
        for i in range(len(comleader)):
            if comleader[i] != key and comleader[i] != index[i]:   
               data_update[comleader[i]-1] = commonleader(comleader[i],index[i],CL,data_update_copy) #计算子组中普通领导者的观点
        tt=0
        for ii in ordinarypeople:
            for j in ii:
                data_update[j-1] = ordinary(j, leader[tt], index[tt],data_update_copy) #计算子组中普通决策者的观点
            tt+=1
        C,collective=Ccollec(data_update)
        GCL=GCL_calcu(C,collective)
        GCL_values.append(GCL)
        print("GCL:", GCL)
        if n==30:
            print("调整失败")
            break
    
    
    ## 计算决策结果
    collective = np.array(collective).reshape(num_alternative, num_attribute*2)
    mu_cols = collective[:,0::2]
    nu_cols = collective[:,1::2]
    decision_outcome=mu_cols-nu_cols
    SA=decision_outcome @ attri1
    support_alternative=np.argmax(SA)+1
    print("最终决策结果为方案",support_alternative)
    
    ##计算每个决策者的支持方案
    data=np.array(data).reshape(num_people,num_alternative*num_attribute*2)
    mu_cols = data[:,0::2]
    nu_cols = data[:,1::2]
    DM_outcome=mu_cols-nu_cols
    DM_support=np.zeros((num_people,1))
    SA_all = np.zeros((num_people, num_alternative))
    for i in range(num_people):
        DM_i=DM_outcome[i,:]
        DM_i=DM_i.reshape(num_alternative,num_attribute)
        SA=DM_i @ attri1
        DM_support[i][0]=np.argmax(SA)+1
        SA_all[i,:] = SA
        
    #df_GCL_values=pd.DataFrame(GCL_values)
    #with pd.ExcelWriter(f'E:/科研/10.PE-DF/0.实验/代码/basic_data_u1_maxcom10/200DM_4alternative_3attribute_{number}.xlsx', engine='openpyxl', mode='a', #if_sheet_exists='replace') as writer:
    #         df_GCL_values.to_excel(writer, sheet_name='GCL', index=False, header=False)
    #print(f"GCL已成功写入工作表。")
    
    #update_outcome=np.vstack((np.array([[support_alternative]]),DM_support))
    #df_DM_support=pd.DataFrame(update_outcome)
    #with pd.ExcelWriter(f'E:/科研/10.PE-DF/0.实验/代码/basic_data_u1_maxcom10/200DM_4alternative_3attribute_{number}.xlsx', engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
    #         df_DM_support.to_excel(writer, sheet_name='decision_outcome', index=False, header=False)
    #print(f"决策结果已成功写入工作表。")
    
    df_SA_values=pd.DataFrame(SA_all)
    with pd.ExcelWriter(f'E:/科研/10.PE-DF/0.实验/代码/basic_data_u1_maxcom10/200DM_4alternative_3attribute_{number}.xlsx', engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
             df_SA_values.to_excel(writer, sheet_name='SA', index=False, header=False)
    print(f"SA已成功写入工作表。")

#numbers=[12,13,148,199,219,325,367,479,489,492,519,526,577,633,663,835,876,997]

for number in range(1,2):
#    AAAAA=pd.read_excel(f"E:/科研/11.PE-DF/1.EJOR一修/代码/basic_data_u1_maxcom10/200DM_4alternative_3attribute_{number}.xlsx",sheet_name='cluster_result',header=None)
#    AAAAA=AAAAA.values
#    if AAAAA.shape[0]<=30:
#        continue
    run_code(number)